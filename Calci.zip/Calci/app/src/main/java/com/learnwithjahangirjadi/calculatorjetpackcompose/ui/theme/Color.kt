package com.learnwithjahangirjadi.calculatorjetpackcompose.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val orange = Color(0xFFFFC107)
val gray = Color(0xFFD6D5D5)
val blueGray = Color(0xFF3E505E)